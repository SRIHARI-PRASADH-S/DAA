"""
CSA06 – Design and Analysis of Algorithms
CO1_AT1: Scalability Audit of ShopSphere
Run: python main.py
"""
import math

OPS_PER_SECOND = 10**8
N = 1_000_000

def m1_comparisons(n):
    return n * (n - 1) // 2

def m2_audits(n):
    # i takes values 1, 2, 4, ... while i < n
    return 2 ** math.ceil(math.log2(n)) - 1 if n > 1 else 0

def binary_search_comparisons(n):
    # Recurrence model T(n)=T(n/2)+1; approximate integer bound
    return math.ceil(math.log2(n)) + 1 if n > 1 else 1

def estimated_seconds(operations):
    return operations / OPS_PER_SECOND

def fmt_time(seconds):
    if seconds < 1:
        return f"{seconds:.6f} seconds"
    return f"{seconds:.2f} seconds ({seconds/60:.2f} minutes)"

def main():
    n = N
    m1 = m1_comparisons(n)
    m2 = m2_audits(n)
    s2 = binary_search_comparisons(n)

    # Asymptotic leading-term estimates; exact constants depend on implementation.
    m4_current = 2 * n * n - n       # recurrence with T(1)=1 for powers of two; leading estimate
    m4_redesign = n * (math.log2(n) + 1)
    m5 = 0.5 * n * (math.log2(n) ** 2) + 0.5 * n * math.log2(n) + n

    print("ShopSphere Scalability Audit")
    print(f"Input size n = {n:,}")
    print(f"Server rate = {OPS_PER_SECOND:,} basic operations/second\n")
    rows = [
        ("M1 Duplicate detector", m1),
        ("M2 API rate limiter", m2),
        ("M3 S2 binary search", s2),
        ("M4 current recommendation engine (estimate)", m4_current),
        ("M4 redesigned recommendation engine (estimate)", m4_redesign),
        ("M5 sales analytics engine (estimate)", m5),
    ]
    for name, ops in rows:
        seconds = estimated_seconds(ops)
        print(f"{name}: {ops:,.0f} operations; estimated time {fmt_time(seconds)}")

    print("\nM2 verification for n=1,024:")
    print(f"Audits = 1 + 2 + 4 + ... + 512 = {m2_audits(1024):,}")

    p = 0.5
    avg_s1 = p * ((1_000_000 + 1) / 2) + (1-p) * 1_000_000
    print("\nS1 expected comparisons for n=1,000,000 and p=0.5:")
    print(f"E[C] = p(n+1)/2 + (1-p)n = {avg_s1:,.2f}")

    print("\nNote: M4/M5 operation totals are model-based estimates; constants and implementation details affect real timings.")
    print("A 10-minute window allows at most 600 * 10^8 = 60,000,000,000 basic operations.")

if __name__ == "__main__":
    main()
